# HackTutor

## Run
```bash
pip install -r requirements.txt
python main.py
```

Then open:
`http://127.0.0.1:5000`

Before running, put your NEW Gemini API key in `config.py`.
